<?php
include('config/config.php');
if (isset($_GET['id_trajet'])) {
    $idtrajet = $_GET['id_trajet'];

    $result=mysqli_query($conn,"SELECT * FROM user WHERE iduser='4' ");
while($tbuser = mysqli_fetch_assoc($result)) {
    $credit= $tbuser['solde'];
    $bon = 0;}
echo $credit;
echo '<br>';
    $getmontant = mysqli_query($conn,"SELECT montant FROM trajet WHERE id_trajet='$idtrajet'");
    while($comp = mysqli_fetch_assoc($getmontant )){
        $montant = $comp['montant'];
     }
     echo $montant;
     echo '<br>';
     $credit=$credit+$montant;
  echo $credit;
  $UpdateQuery ="UPDATE user SET solde ='$credit'";
  $conn->query($UpdateQuery);
    //echo $montant;

    $sql = "DELETE FROM trajet WHERE id_trajet=$idtrajet";
     $result = mysqli_query($conn, $sql);

     if($result){
        ?>
        <script>alert('Operqtion effectuee avec succes !')</script>
        <?php
        echo '<script type = "text/javascript"> window.location = "gareviewlabelle.php";</script>';
    }else{
      ?>
      <script>alert("Erreur d'annulation")</script>
      <?php
    }

 }

?>
