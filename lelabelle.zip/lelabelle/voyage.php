<!-- TRAITEMENT POUR GENERER LE CODE DE VOYAGE DU GAR ET L'AFFICHER -->
<?php
include'config/config.php';
include './views/voyage.views.php';

$depart = "";
$arrive = "";
$ticket = "";
$montant = '';

  if(isset($_POST['valider'])){
      $depart = $_POST['villeDepart'];
      $arrive = $_POST['villeArrive'];
      $ticket='TK'.uniqid();
      //----------- SELECTION DU MONTANT DANS LA TABLE TRAJET OU LE DEPART ET L'ARRIVE CORRESPONDENT AUX VARIABLE DE L'USER
      if(!empty($depart) || !empty($arrive)){
        $trouveville = mysqli_query($conn, "SELECT * FROM destination WHERE departville = '$depart' AND arriveville = '$arrive'");
        $rows = mysqli_num_rows($trouveville);
        if ($rows == 0) {
          echo 'cet itineraire n\'est pas encore disponible';
        } else {
          $trouveville = mysqli_fetch_array($trouveville);
          $tarif = $trouveville['montant'];
         //-----------INSERTION DES INFOS DU CLIENTS DANS LA TABLE
        $sql = mysqli_query($conn, "INSERT INTO trajet(depart, arrive, ticket, montant) VALUES ('$depart', '$arrive', '$ticket', '$tarif')");
        echo 'Pour votre voyage de '.$depart.'  a  '.$arrive.', le numero de votre ticket est le suivant ' .$ticket .', avec un tarif de ' . $tarif;
        if($sql){
         ?>
         <script>alert('Reservation pris avec succes !')</script>

         <?php
         echo '<script language="Javascript">';
         echo 'window.location = "users.php"'; // -->
         echo ' </script>';
        }else{
          ?>
          <script>alert("Erreur d'annulation")</script>
          <?php
        }
     }
     }
  }
  ?>
