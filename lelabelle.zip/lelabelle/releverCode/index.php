<?php
include('conn.php');
//include('voyage.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
	<link rel = "stylesheet" href = "css/style.css">
    <title>Relever de code</title>
</head>
<body>
    <div class="container-fluid">
    <div class="row">
        <table class="table table-striped table-bordered">
	      <thead>
		<tr>
		    <th>Ville de depart</th>
			<th>Ville d'arrivee</th>
		    <th>Numero du ticket</th>
			<th>Tarification</th>
		    <th>Annuler voyage</th>
			<th>Voyage Effectuer</th>
		</tr>
		</thead>
	   <tbody>
	   <?php
		   $sql = "SELECT* FROM trajet";
		   $result = mysqli_query($conn, $sql)
		   or die("echec de connection a la base de donnee:".mysqli_error($conn));
		   while($rows = mysqli_fetch_assoc($result)){
			$ok = $rows['ticketutilise'];
           ?>
		  <tr>
		     <td><?php echo $rows['depart'];?></td>
			 <td><?php echo $rows['arrive'];?></td>
			 <td><?php echo $rows['ticket'];?></td>
			 <td><?php echo $rows['montant'];?></td> 
			 <td>
            <?php
			if($ok == 'utilise'){
				?> 
			 <a class="btn btn-danger disabled"href="delete.php?id_trajet=<?php echo $rows['id_trajet'];?>" 
			 onclick = "return confirm('voulez vous annuler votre voyage ?')">
			 <i class="glyphicon glyphicon-trash"></i>
			 </a>
			 <?php
			 }else{ 
				 ?>
				<a class="btn btn-danger "href="delete.php?id_trajet=<?php echo $rows['id_trajet'];?>" 
			 onclick = "return confirm('voulez vous annuler votre voyage ?')">
			 <i class="glyphicon glyphicon-trash"></i>
			 </a>
			 <?php
			 }	
			 ?> 
			 </td>
			 <td>
			<?php
			//$ok = $rows['ticketutilise'];
			   if($ok == 'utilise'){

                  echo '<img src = "ok.png" width = 30px>';
			   }else{
				   echo '---';
			   }
			?>
			 </td>
		   </tr>
		   <?php
		   }
		   ?>
	  </tbody>
	  </table>
    </div>
    </div>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script src = "https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
	<!--<script type="text/javascript" src="script/bootbox.min.js"></script>-->
	<script type="text/javascript" src="js/delete.js"></script>
</body>
</html>