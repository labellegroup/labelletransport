
<form action="" methode="POST">
code du ticket: <input type="text" name="codetk" required><br>
<input type="submit" value="verifier">
</form>

<?php
    if (isset($_POST['verifier']) && isset($_POST['codetk'])) {
        $codeticket =addslashes($_post['codetk']);

        $verif=mysqli_query($conn,"SELECT * FROM ticket WHERE codeticket='$codeticket'");    

      while($tbticket = mysqli_fetch_assoc($verif)) { 
          $ticket = $tbticket['codeticket']; 
          $tkprix = $tbticket['prix']; 
          $userid = $tbticket['iduser'];         
      }
      $tkprix = 0;
       $getPrix = mysqli_query($conn,"SELECT prix FROM ticket WHERE codeticket='$codeticket'");
       while($tik = mysqli_fetch_assoc($getPrix)){
          $tkprix = $tik['prix'];
       }
       $credit=$credit-$tkprix;
       $UpdateQuery ="UPDATE user SET solde ='$credit' WHERE iduser='$userid' ";
       $conn->query($UpdateQuery);

      echo "<font color = 'green'>";
      echo   $userid.' '.$codeticket;
      echo "<B>Vous avez ete debite de: ".$tkprix." F CFA, suite a l'achat de votre ticket/B>";
      echo "</font>";
      echo "<br>";  
    }
?>