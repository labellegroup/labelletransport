<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Page non trouvee</title>
    <link rel="stylesheet" href="assets/css/error-page.css">
  </head>
  <body>




    <div class="errordiv">

        <center>  <h1>OOPS ! <br> AVEZ-VOUS ENTRER LA BONNE ADRESSE ?</h1> </center>

      </div>



  </body>
</html>
