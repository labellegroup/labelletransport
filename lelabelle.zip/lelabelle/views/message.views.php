<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php include 'config/header1.php' ?>

    <br><br><br>
    <center>  <H1>MA BOITE DE MESSAGERIE</H1> </center>

    <div class="container ">
      <table class="table table-bordered table-md table-success">
        <thead class="table-warning">
          <tr>
            <th>N*</th>
            <th>DE</th>
            <th>A</th>
            <th>OBJET</th>
            <th>MESSAGE</th>
            <th>DATE ET HEURE</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>le labelle</td>
            <td>Alain</td>
            <td>CODE BON</td>
            <td>Bonjour, votre compte a ete credite de 20000 f cfa</td>
            <td>09h00</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        </tbody>
      </table>

    </div>

    <br><br><br><br>

    <?php include 'config/footer.php' ?>
  </body>
</html>
