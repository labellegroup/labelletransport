<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>


    <?php include './config/header1.php'; ?>

    <center>
    <form  action="" method="post">

    CODE DU BON: <br> <input type="text" placeholder="Entrez CODE DU BON" name="codedebon" required>
        <input type="submit" name = "valider" value="VALIDER">
        <input class="cancelbtn" type="reset" name = "reset" value="ANNULER">

    </form>
    </center>
  </body>
</html>
