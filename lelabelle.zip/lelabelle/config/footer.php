<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/footer.css">
    <title></title>
</head>
<body>
    <div class="container footer">
        <div class="row">
            <div class="col-sm-6">
                <ul>
                    <li><img src="images/phone.png"  alt="">+225 00000000</li>
                    <li><img src="images/email.png"  alt="">lelabelle.group@gmail.com</li>
                </ul>
            </div>
            <div class="col-sm-6">
            <ul>
                <li>
                    <img src="images/map.png" alt=""> Cocody, Ecole de police (Abidjan - Côte d'ivoire)
                </li>
            </ul>
            </div>
        </div>

    </div>

    <center>
      <p>Website by <strong style="color:orange">lelabelle GROUP</strong>, Copyright (C) 2019. All rights reserveds  </p>
    </center>
</body>
</html>
