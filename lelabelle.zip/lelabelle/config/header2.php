<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/header1.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <title>Second header</title>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6">

        <nav class="navbar navbar-expand-md bg-light">
  <!--Logo -->
        <a class="navbar-brand" href="#">
            <img src="images/lelabelle.png" alt="logo" style="width:200px;">
         </a>
        </nav>
        </div>
        <div class="col-md-6 ">
        <nav class="navbar navbar-expand-md bg-light">
          <?php if(isset($_SESSION['logged_in'])): ?>
            <nav >
            <span id="login">
                Bienvenue, <?php echo $_SESSION['prenom']; ?>
            </span> <br>
            <span class="login">
                Votre solde : <?php echo $_SESSION['solde']; ?>
            </span id="login"> <br>
            <span style='color:orange'>
                <a href="user_dashboard.php?logout='true'">Déconnexion</a>
            </span>
            </nav>
            <?php endif ?>
        </div>
    </div>
</div>

<div class="container menu">
    <div class="row">
        <div class="col-md-2">
            <a href="">Accueil</a>
        </div>
        <div class="col-md-2">
            <a href="profile.php">Editer</a>
        </div>
        <div class="col-md-2">
            <a href="">Offres</a>
        </div>
        <div class="col-md-2">
            <a href="">Voyage</a>
        </div>
         <div class="col-md-2">
            <a href="">Message</a>
        </div>
        <div class="col-md-2">
            <a href="recharger.php">Credit</a>
        </div>
    </div>
</div>
</body>
</html>
